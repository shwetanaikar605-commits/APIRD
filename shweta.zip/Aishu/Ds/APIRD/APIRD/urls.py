from django.contrib import admin
from django.urls import path
from Drinks.views import home,get_post_drinks,get_put_delete_drink
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home),
    path('drinks/', get_post_drinks),
    path('drinks/<int:id>/', get_put_delete_drink)

]